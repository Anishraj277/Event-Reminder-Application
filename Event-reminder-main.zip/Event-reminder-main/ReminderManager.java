import java.io.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Comparator;

public class ReminderManager implements Serializable {
    private static final long serialVersionUID = 1L;
    private ArrayList<Event> eventList;


    public ReminderManager() {
        eventList = new ArrayList<>();
    }


    public void addEvent(Event event) {
        eventList.add(event);
        System.out.println("✅ Event added to the list.");
    }


    public void viewEvents() {
        if (eventList.isEmpty()) {
            System.out.println("⚠️ No events to display.");
            return;
        }

        eventList.sort(Comparator.comparing(Event::getDate));
        System.out.println("\n📅 -- Event List --");

        for (int i = 0; i < eventList.size(); i++) {
            printFormattedEvent(i, eventList.get(i));
        }
    }


    public void showCompletedEvents() {
        if (eventList.isEmpty()) {
            System.out.println("⚠️ No events in the list.");
            return;
        }

        System.out.println("\n✅ Completed Events:");
        boolean found = false;
        for (int i = 0; i < eventList.size(); i++) {
            Event e = eventList.get(i);
            if (e.getEventStatus()) {
                printFormattedEvent(i, e);
                found = true;
            }
        }

        if (!found)
            System.out.println("⚠️ No completed events to show.");
    }


    public void updateEventStatus(int index) {
        if (index < 0 || index >= eventList.size()) {
            System.out.println("❌ Invalid index. Cannot update.");
            return;
        }

        eventList.get(index).setEventStatus(true);
        System.out.println("✅ Event marked as completed.");

        handleRecurringEvent(index);
    }


    public void handleRecurringEvent(int index) {
        Event event = eventList.get(index);
        if (event.getRecurrence() == Event.Recurrence.NONE) return;

        LocalDate nextDate = switch (event.getRecurrence()) {
            case DAILY -> event.getDate().plusDays(1);
            case WEEKLY -> event.getDate().plusWeeks(1);
            case MONTHLY -> event.getDate().plusMonths(1);
            case YEARLY -> event.getDate().plusYears(1);
            default -> null;
        };

        if (nextDate != null) {
            Event nextEvent = new Event(
                    event.getTitle(),
                    event.getDescription(),
                    nextDate,
                    event.getRecurrence()
            );
            addEvent(nextEvent);
            System.out.println("🔁 New recurring event scheduled: " + nextEvent.getTitle() + " on " + nextEvent.getDate());
        }
    }


    public void removeEvent(int index) {
        if (index < 0 || index >= eventList.size()) {
            System.out.println("❌ Invalid index. Cannot remove event.");
            return;
        }

        System.out.println("🗑️ Removed: " + eventList.get(index).getTitle());
        eventList.remove(index);
    }


    public int getSize() {
        return eventList.size();
    }


    public void saveToFile(String filename) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filename))) {
            oos.writeObject(eventList);
            System.out.println("💾 Events saved to file.");
        } catch (IOException e) {
            System.out.println("❌ Failed to save events: " + e.getMessage());
        }
    }


    @SuppressWarnings("unchecked")
    public void loadFromFile(String filename) {
        File file = new File(filename);
        if (!file.exists()) {
            System.out.println("ℹ️ No previous data found. Starting empty.");
            return;
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(file))) {
            eventList = (ArrayList<Event>) ois.readObject();
            System.out.println("📂 Events loaded from file.");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("❌ Failed to load events: " + e.getMessage());
            eventList = new ArrayList<>();
        }
    }


    private void printFormattedEvent(int index, Event e) {
        String statusText = e.getEventStatus() ? "✅ Completed" : "⏳ Upcoming";
        long daysLeft = ChronoUnit.DAYS.between(LocalDate.now(), e.getDate());
        String timeLeft = e.getEventStatus() ? "Done"
                : (daysLeft >= 0 ? daysLeft + " day(s) left" : "⌛ Past due!");

        String color;
        if (e.getEventStatus()) {
            color = "\u001B[32m"; // Green
        } else if (daysLeft < 0) {
            color = "\u001B[31m"; // Red
        } else {
            color = "\u001B[33m"; // Yellow
        }

        String reset = "\u001B[0m";
        System.out.println(color + (index + 1) + ". " + e.getTitle() + reset);
        System.out.println("   📋 Description: " + e.getDescription());
        System.out.println("   📅 Date: " + e.getDate());
        System.out.println("   📝 Status: " + statusText + " | " + timeLeft);
        System.out.println("   🔁 Recurrence: " + e.getRecurrence());
        System.out.println();
    }
}
