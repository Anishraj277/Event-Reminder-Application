import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Executor {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ReminderManager rm = new ReminderManager();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        String filePath = "events.dat";


        rm.loadFromFile(filePath);

        while (true) {
            System.out.println("\n=== 📆 Event Reminder System Menu ===");
            System.out.println("1. Add Event");
            System.out.println("2. View All Events");
            System.out.println("3. Show Completed Events");
            System.out.println("4. Remove Event");
            System.out.println("5. Mark Event as Completed");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            int choice = -1;
            try {
                choice = Integer.parseInt(sc.nextLine());
            } catch (Exception e) {
                System.out.println("❌ Invalid input. Please enter a number.");
                continue;
            }

            switch (choice) {
                case 1:
                    try {
                        System.out.print("Enter Title: ");
                        String title = sc.nextLine();

                        System.out.print("Enter Description: ");
                        String description = sc.nextLine();

                        System.out.print("Enter Date (yyyy-MM-dd): ");
                        String dateInput = sc.nextLine();
                        LocalDate date = LocalDate.parse(dateInput, formatter);

                        System.out.print("Enter Recurrence (none/daily/weekly/monthly/yearly): ");
                        String recStr = sc.nextLine().trim().toLowerCase();
                        Event.Recurrence recurrence;
                        switch (recStr) {
                            case "daily": recurrence = Event.Recurrence.DAILY; break;
                            case "weekly": recurrence = Event.Recurrence.WEEKLY; break;
                            case "monthly": recurrence = Event.Recurrence.MONTHLY; break;
                            case "yearly": recurrence = Event.Recurrence.YEARLY; break;
                            default: recurrence = Event.Recurrence.NONE; break;
                        }

                        Event event = new Event(title, description, date, recurrence);
                        rm.addEvent(event);
                        rm.saveToFile(filePath);
                    } catch (Exception e) {
                        System.out.println("❌ Invalid input! Make sure date format is yyyy-MM-dd.");
                    }
                    break;

                case 2:
                    rm.viewEvents();
                    break;

                case 3:
                    rm.showCompletedEvents();
                    break;

                case 4:
                    rm.viewEvents();
                    if (rm.getSize() == 0) break;
                    System.out.print("Enter event number to remove: ");
                    try {
                        int indexRemove = Integer.parseInt(sc.nextLine()) - 1;
                        rm.removeEvent(indexRemove);
                        rm.saveToFile(filePath);
                    } catch (Exception e) {
                        System.out.println("❌ Invalid input. Please enter a valid number.");
                    }
                    break;

                case 5:
                    rm.viewEvents();
                    if (rm.getSize() == 0) break;
                    System.out.print("Enter event number to mark as completed: ");
                    try {
                        int indexUpdate = Integer.parseInt(sc.nextLine()) - 1;
                        rm.updateEventStatus(indexUpdate);
                        rm.saveToFile(filePath);
                    } catch (Exception e) {
                        System.out.println("❌ Invalid input. Please enter a valid number.");
                    }
                    break;

                case 6:
                    System.out.println("💾 Saving events and exiting. Goodbye!");
                    rm.saveToFile(filePath);
                    sc.close();
                    return;

                default:
                    System.out.println("⚠️ Invalid choice. Please select from the menu.");
                    break;
            }
        }
    }
}
