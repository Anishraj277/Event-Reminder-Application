import java.io.Serializable;
import java.time.LocalDate;

public class Event implements Serializable {
    private static final long serialVersionUID = 1L;

   
    private String title;
    private String description;
    private LocalDate date;
    private boolean isCompleted;
    private Recurrence recurrence;


    public Event(String title, String description, LocalDate date, Recurrence recurrence) {
        this.title = title;
        this.description = description;
        this.date = date;
        this.isCompleted = false;
        this.recurrence = recurrence;
    }


    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public LocalDate getDate() {
        return date;
    }

    public boolean getEventStatus() {
        return isCompleted;
    }

    public Recurrence getRecurrence() {
        return recurrence;
    }


    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public void setEventStatus(boolean isCompleted) {
        this.isCompleted = isCompleted;
    }

    public void setRecurrence(Recurrence recurrence) {
        this.recurrence = recurrence;
    }


    public enum Recurrence {
        NONE,
        DAILY,
        WEEKLY,
        MONTHLY,
        YEARLY
    }
}
